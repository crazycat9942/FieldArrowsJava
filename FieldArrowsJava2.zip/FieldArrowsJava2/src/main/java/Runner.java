
public class Runner
{
    public static void main(String[] args)
    {
        Main temp = new Main();
    }
}
